<?php
include 'C:\xampp\htdocs\test1\check_cookie.php';
include 'C:\xampp\htdocs\test1\get_user_from_cookie.php';
include 'C:\xampp\htdocs\test1\check_usernames_sqli.php';
include 'C:\xampp\htdocs\test1\write_log.php';
include 'C:\xampp\htdocs\test1\read_log.php';


require dirname(__DIR__) . '/vendor/autoload.php';
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

$cookies = array();
class Chat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
		
		#echo $cookie_exist;
        $this->clients->attach($conn);
		
		/////////////////////// Check cookie //////////////////////////
		$open_websocket = False;
		$cookie_exist = 0;
		$cookies = $conn->httpRequest->getHeader('Cookie');
		$arrlength = count($cookies);
		for($x = 0; $x < $arrlength; $x++) {
			
			#echo $cookies[$x];
			$cookie_name = explode("=", $cookies[$x])[0];
			if ($cookie_name == "sessionID") {
				
				$cookie_exist = 1;
				$cookie_value = explode("=", $cookies[$x])[1];
				if (check_cookie($cookie_value)) {
					$open_websocket = True;
					$GLOBALS['cookies'][$conn->resourceId] = $cookie_value;
					echo "cookie is valid!";
				}
			}
		}
		#echo $cookie_exist;
		if (!($cookie_exist)) {
			echo "cookie not exist!";
		}
		///////////////////////////////////////////////////////////////
		
		/////////////////////// Check origin //////////////////////////
		$origin = $conn->httpRequest->getHeader('Origin')[0];
		echo $origin;
		if ($origin != 'http://websockettest.com') {
			$open_websocket = False;	
		}
		////////////////////////////////////////////////////////////////
		if ($open_websocket == False) {
			$conn->close(); 
		}
		#print_r ($cookies);
        echo "New connection! ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        if (explode(":",$msg)[0] != "logs"){
			$cookie = $GLOBALS['cookies'][$from->resourceId];
			$username = get_user_from_cookie($cookie);
			$msg2 = "<br>[*]'".$username . "' send message at ".date('Y/m/d H:i:s')."\n";	
			write_log($msg2);
			$numRecv = count($this->clients) - 1;
			echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
            , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');
		}
		
		if (explode(":",$msg)[0] == "usertosearch") {
			foreach ($this->clients as $client) {
				if ($from === $client) {
					
					$username_to_search = explode(":",$msg)[1];
					//$username_to_search = (int)$username_to_search;
					$msg1 = "usertosearch:".check_usernames($username_to_search);
					$client->send($msg1);
				}
			}
		} elseif (explode(":",$msg)[0] == "logs") {
			foreach ($this->clients as $client) {
				if ($from === $client) {
					$msg6 = "logs:".read_log(explode(":",$msg)[1]);
					$client->send($msg6);
				}
			}
		} else {
			foreach ($this->clients as $client) {
				$cookie = $GLOBALS['cookies'][$from->resourceId];
				$username = get_user_from_cookie($cookie);
				$client->send("<div class=\"w3-panel w3-border w3-border-red\" style=\"width:30%;margin-left:35%;\">".$username.": <b style=\"word-wrap:break-word;\">".$msg."</b></div>");
				/* if ($from !== $client) {
					// The sender is not the receiver, send to each client connected
					$cookie = $GLOBALS['cookie'];
					$username = get_user_from_cookie($cookie);
					$client->send("<div class=\"w3-panel w3-border w3-border-red\" style=\"width:30%;margin-left:35%;\">".$username.": <b style=\"word-wrap:break-word;\">".$msg."</b></div>");
				} */
			}
		}
    }

    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->clients->detach($conn);

        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}

?>