<?php
include 'C:\xampp\htdocs\test1\check_cookie.php';
include 'C:\xampp\htdocs\test1\get_user_from_cookie.php';
include 'C:\xampp\htdocs\test1\check_usernames.php';
include 'C:\xampp\htdocs\test1\write_log.php';
include 'C:\xampp\htdocs\test1\read_log.php';

require dirname(__DIR__) . '/vendor/autoload.php';
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

$cookies = array();
class Chat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        // Store the new connection to send messages to later
        $this->clients->attach($conn);
		$cookies = $conn->httpRequest->getHeader('Cookie');
		$arrlength = count($cookies);
		for($x = 0; $x < $arrlength; $x++) {
			
			#echo $cookies[$x];
			$cookie_name = explode("=", $cookies[$x])[0];
			if ($cookie_name == "sessionID") {
				$cookie_value = explode("=", $cookies[$x])[1];
				if (check_cookie($cookie_value)) {
					$open_websocket = True;
					$GLOBALS['cookies'][$conn->resourceId] = $cookie_value;
				}
			}
		}
		$cookie = $GLOBALS['cookies'][$conn->resourceId];
		$username = get_user_from_cookie($cookie);
		$msg = "<br>[*]New connection in the house! '".$username."' (with id - {$conn->resourceId})\n";
        echo $msg;
		write_log($msg);
    }

    public function onMessage(ConnectionInterface $from, $msg) {
		if (explode(":",$msg)[0] != "logs"){
			$cookie = $GLOBALS['cookies'][$from->resourceId];
			$username = get_user_from_cookie($cookie);
			$msg2 = "<br>[*]'".$username . "' send message at ".date('Y/m/d H:i:s')."\n";	
			write_log($msg2);
			$numRecv = count($this->clients) - 1;
			echo sprintf('Connection %d sending message "%s" to %d other connection%s' . "\n"
            , $from->resourceId, $msg, $numRecv, $numRecv == 1 ? '' : 's');
		}
        

        if (explode(":",$msg)[0] == "usertosearch") {
			foreach ($this->clients as $client) {
				if ($from === $client) {
					$username_to_search = explode(":",$msg)[1];
					$msg1 = "usertosearch:".check_usernames($username_to_search);
					$client->send($msg1);
				}
			}
		} elseif (explode(":",$msg)[0] == "logs") {
			foreach ($this->clients as $client) {
				if ($from === $client) {
					$msg6 = "logs:".read_log(explode(":",$msg)[1]);
					$client->send($msg6);
				}
			}
		} else {
			foreach ($this->clients as $client) {
				$cookie = $GLOBALS['cookies'][$from->resourceId];
				$username = get_user_from_cookie($cookie);
				$client->send("<div class=\"w3-panel w3-border w3-border-red\" style=\"width:30%;margin-left:35%;\">".htmlspecialchars($username).": <b style=\"word-wrap:break-word;\">".htmlspecialchars($msg)."</b></div>");
				/* if ($from !== $client) {
					// The sender is not the receiver, send to each client connected
					$cookie = $GLOBALS['cookie'];
					$username = get_user_from_cookie($cookie);
					$client->send("<div class=\"w3-panel w3-border w3-border-red\" style=\"width:30%;margin-left:35%;\">".$username.": <b style=\"word-wrap:break-word;\">".$msg."</b></div>");
				} */
			}
		}
    }

    public function onClose(ConnectionInterface $conn) {
        // The connection is closed, remove it, as we can no longer send it messages
        $this->clients->detach($conn);
		
		$cookie = $GLOBALS['cookies'][$conn->resourceId];
		$username = get_user_from_cookie($cookie);
		
		$msg5 = "<br>[*]User '".$username."' has disconnected ({$conn->resourceId})\n";
        echo $msg5;
		write_log($msg5);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";

        $conn->close();
    }
}

?>