 <?php

$insertToDB = false;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login_username"]) && isset($_POST["login_password"]) && !empty($_POST["login_username"]) && !empty($_POST["login_password"])) {
	$insertToDB = true;
} else {
	?>
	<h1>Something is wrong with your login details!</h1>
	<script>
		setTimeout(function () {
		   window.location.href= '/test1/portal.php'; // the redirect goes here

		},2000);
	</script>
	<?php
	die();
}

if ($insertToDB) {
	$servername = "localhost";
	$username = "test";
	$password = "test";
	$dbname = "websocket";

	// Create connection
	
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("SELECT username FROM users WHERE username=(?) and password=(?)");
	$stmt->bind_param("ss", $login_username, $login_password);
	
	$login_username = $_POST["login_username"];
	$login_password = $_POST["login_password"];
	$stmt->execute();
	
	$result = $stmt->get_result();

	if ($result->num_rows > 0) {
		// output data of each row
		$cookie_name = "sessionID";
		$cookie_value = rand();
		setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
	} else {
		?>
		<h1>Something is wrong with your login details!</h1>
		<script>
			setTimeout(function () {
			   window.location.href= '/test1/portal.php'; // the redirect goes here

			},2000);
		</script>
	<?php
		die();
	}

	// prepare and bind
	$stmt = $conn->prepare("INSERT INTO cookies (username, cookie) VALUES (?, ?)");
	$stmt->bind_param("ss", $login_username, $cookie_value);

	// set parameters and execute
	$login_username = $_POST["login_username"];
	$cookie_value = $cookie_value;
	$stmt->execute();


	?>
		<h1>Login successfuly!</h1>
		<script>
			setTimeout(function () {
			   window.location.href= '/test1/'; // the redirect goes here

			},2000);
		</script>
	<?php

	$stmt->close();
	$conn->close();
}
?> 