<?php
function write_log($event){
	$myfile = fopen("C:\\xampp\\htdocs\\test1\\logs\\logs.txt", "a") or die("Unable to open file!");
	fwrite($myfile, $event);
	fclose($myfile);
}
?>