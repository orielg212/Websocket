<?php
function check_usernames($username_to_check){
	
	$servername = "localhost";
	$username = "test";
	$password = "test";
	$dbname = "websocket";

	// Create connection
	
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	if (empty($username_to_check)) {
		return "No user found!";
	}
	$sql = "SELECT username FROM users WHERE username LIKE '".$username_to_check."%'"; // ' or '1'='1' -- // ' union all select password from users --
	//$sql = "SELECT username FROM users WHERE username='".$username_to_check."'"; //  ' or '1'='1    // ' order by 2 -- %20 // ' union all select password from users -- 
	$result = $conn->query($sql);
	if (mysqli_error($conn)){
		return mysqli_error($conn);
	}
	if ($result->num_rows > 0) {
		$usernames_to_send = '';
		while($row = $result->fetch_assoc()) {
			$usernames_to_send = $usernames_to_send.$row["username"]."<br>";
		}
		
		return $usernames_to_send;
	} else {
		return "No user found!";
	}
}