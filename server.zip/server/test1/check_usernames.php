<?php
function check_usernames($username_to_check){
	
	$servername = "localhost";
	$username = "test";
	$password = "test";
	$dbname = "websocket";

	// Create connection
	
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	if (empty($username_to_check)) {
		return "No user found!";
	}
	$stmt = $conn->prepare("SELECT username FROM users WHERE username LIKE CONCAT(?,'%') ");
	$stmt->bind_param("s", $username);
	
	$username = $username_to_check;

	$stmt->execute();
	
	$result = $stmt->get_result();

	if ($result->num_rows > 0) {
		$usernames_to_send = '';
		while($row = $result->fetch_assoc()) {
			$usernames_to_send = $usernames_to_send.$row["username"]."<br>";
		}
		
		return $usernames_to_send;
	} else {
		return "No user found!";
	}
}