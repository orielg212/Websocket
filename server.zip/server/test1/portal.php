<?php
$cookie_name = "sessionID";


if(isset($_COOKIE[$cookie_name])) {

} else {
    
}

?>
<!DOCTYPE html>
<html>
<title>Login page</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>

function register(){
	register_username = document.getElementById("register_username").value
	register_password = document.getElementById("register_password").value
	
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      alert(this.responseText);
    }
  };
  xhttp.open("POST", "register.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("register_username="+register_username+"&register_password="+register_password);
  
}
</script>
<body>
<h1 style="margin-top:5%" class="w3-xxxlarge w3-center">Websocket login</h1>
<div style="margin-top:10%">
<div class="w3-container w3-half">
  <h2 class="w3-center w3-blue">Register</h2>


<div class="w3-container">
  <p>
  <label>Username</label>
  <input id="register_username" class="w3-input" type="text"></p>
  <p>
  <label>Password</label>
  <input id="register_password" class="w3-input" type="text"></p>
  <p>
  <div class="w3-center" >
  <button onclick="register()" class="w3-btn w3-blue">Register</button>
  </div>
</div>
</div>

<div class="w3-container w3-half">
  <h2 class="w3-center w3-red">Login</h2>


<div class="w3-container">
<form action="/test1/login.php" method="POST">
  <p>
  <label>Username</label>
  <input name="login_username" class="w3-input" type="text"></p>
  <p>
  <label>Password</label>
  <input name="login_password" class="w3-input" type="text"></p>
  <p>
  <div class="w3-center" >
  <button type="submit" class="w3-btn w3-red">Login</button>
	</div>
</form>	
</div>
</div>
</div>

</body>
</html> 