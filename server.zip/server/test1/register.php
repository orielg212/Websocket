 <?php

$insertToDB = false;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["register_username"]) && isset($_POST["register_password"]) && !empty($_POST["register_username"]) && !empty($_POST["register_password"])) {
	$insertToDB = true;
} else {
	echo "Something is wrong with your registration details!";
}

if ($insertToDB) {
	$servername = "localhost";
	$username = "test";
	$password = "test";
	$dbname = "websocket";

	// Create connection
	
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$stmt = $conn->prepare("SELECT username FROM users WHERE username=(?)");
	$stmt->bind_param("s", $register_username);
	
	$register_username = $_POST["register_username"];
	$stmt->execute();
	
	$result = $stmt->get_result();

	if ($result->num_rows > 0) {
		// output data of each row
		die("User already exist!");
	}

	// prepare and bind
	$stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
	$stmt->bind_param("ss", $register_username, $register_password);

	// set parameters and execute
	$register_username = $_POST["register_username"];
	$register_password = $_POST["register_password"];
	$stmt->execute();

	echo "User was created successfully!";

	$stmt->close();
	$conn->close();
}
?> 