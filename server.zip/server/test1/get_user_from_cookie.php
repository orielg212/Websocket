<?php
function get_user_from_cookie($cookie){
	$servername = "localhost";
	$username = "test";
	$password = "test";
	$dbname = "websocket";

		// Create connection
		
		$conn = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($conn->connect_error) {
			return "No user";
		}


		$stmt = $conn->prepare("SELECT username FROM cookies WHERE cookie=(?) LIMIT 1");
		$stmt->bind_param("s", $cookie_value);
		
		$cookie_value = $cookie;
		
		$stmt->execute();
		
		$result = $stmt->get_result();

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				return $row["username"]; 
			}
		} else {
			return "No user";
		}
		
	}
?>