 <?php
$servername = "localhost";
$username = "test";
$password = "test";
$dbname = "websocket";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE users (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "\n[+]Table users created successfully";
} else {
    echo "Error creating table: " . $conn->error . "\n";
}

// sql to create table
$sql = "CREATE TABLE cookies (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(30) NOT NULL,
cookie VARCHAR(250) NOT NULL,
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "\n[+]Table cookies created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}



// sql to create table
/* $sql = "CREATE TABLE websocket (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(30) NOT NULL,
cookie VARCHAR(250) NOT NULL,
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "\n[+]Table cookies created successfully";
} else {
    echo "Error creating table: " . $conn->error;
} */




$conn->close();
?> 