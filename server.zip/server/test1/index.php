<?php 
include 'check_cookie.php';
include 'get_user_from_cookie.php';
$cookie_name = "sessionID";

if(isset($_COOKIE[$cookie_name])) {
	if (check_cookie($_COOKIE[$cookie_name])) {
		#echo "You are valid!";
	} else {
		header("Refresh:2; url=/test1/portal.php");
		die("You are not valid!");
	}
} else {
    header("Refresh:2; url=/test1/portal.php");
	die("You are not valid!");
}
$username = get_user_from_cookie($_COOKIE[$cookie_name]);
?>
<html ng-app="app">
<title>WebSocket</title>
<!-- Play with "url" parameter for xss -->
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<head>
    <script type="text/javascript">
    var myWebSocket;
    function connectToWS() {
		messages = document.getElementById("messages");
		userslist = document.getElementById("userslist");
		dispalyMessage = '';
        var endpoint = document.getElementById("endpoint").value;
		//alert(endpoint);
        if (myWebSocket !== undefined) {
            myWebSocket.close()
        }

        myWebSocket = new WebSocket(endpoint);
		
		
		
        myWebSocket.onmessage = function(event) {
            var leng;
            if (event.data.size === undefined) {
                leng = event.data.length
            } else {
                leng = event.data.size
            }
            console.log("onmessage. size: " + leng + ", content: " + event.data);
			response = event.data;
			var vartoinsert = response.split(":")[0];
			//alert(response.split(":")[0]);
			if (vartoinsert=='usertosearch'){
				document.getElementById("userslist").innerHTML = response.split(":")[1];
			} else if (vartoinsert=='logs'){
				var rsp = response.substring(9);
				document.getElementById("logs").innerHTML = rsp;
			} else if (event.data.includes("xss:")){
				document.getElementById("xss").innerHTML = event.data;
			} else {
				dispalyMessage = dispalyMessage+event.data;
				messages.innerHTML =  dispalyMessage;
			}
			
			
        }

        myWebSocket.onopen = function(evt) {
            console.log("Websocket is open!");
			document.getElementById("connect_button").classList.add("w3-hide");
			document.getElementById("disconnect_button").classList.remove("w3-hide");
			//dispalyMessage = dispalyMessage+"<br>Websocket is open!"; 
			
			document.getElementById("chatchat").className = "w3-border-right w3-half w3-show"
			document.getElementById("searchusers").className = "w3-half w3-show"
			document.getElementById("logs").className = "w3-border w3-gray w3-show"
			document.getElementById("input_logs").className = "w3-show"
			
			
			document.getElementById("websocketstatus").innerHTML = "Websocket is open!";
			//messages.innerHTML = dispalyMessage;
			getlogs();
			urlXSS();
        };

        myWebSocket.onclose = function(evt) {
            console.log("onclose.");
			document.getElementById("connect_button").classList.remove("w3-hide");
			document.getElementById("disconnect_button").classList.add("w3-hide");
			//dispalyMessage = dispalyMessage+"<br>Websocket is close!"; 
			
			document.getElementById("chatchat").className = "w3-hide"
			document.getElementById("searchusers").className = "w3-hide"
			document.getElementById("logs").className = "w3-hide"
			document.getElementById("input_logs").className = "w3-hide"
			
			document.getElementById("websocketstatus").innerHTML = "Websocket is close!";
			//messages.innerHTML = dispalyMessage
        };

        myWebSocket.onerror = function(evt) {
            console.log("Error!");
			document.getElementById("websocketstatus").innerHTML = "Error to open Websocket!";
			//dispalyMessage = dispalyMessage+"<br>Error to open Websocket!"; 
			//messages.innerHTML = dispalyMessage
        };
    }

    function sendMsg() {
        var message = document.getElementById("myMessage").value;
        myWebSocket.send(message);
		//dispalyMessage = dispalyMessage+"<br>"+message; 
		//messages.innerHTML = dispalyMessage; 
    }
	
	function searchusers() {
        var usertosearch = "usertosearch:"+document.getElementById("usertosearch").value;
        myWebSocket.send(usertosearch);
		//dispalyMessage = dispalyMessage+"<br>"+message; 
		//messages.innerHTML = dispalyMessage; 
		//alert(1);
    }
	
    function closeConn() {
        myWebSocket.close();
    }
	
	function urlXSS() {
		// your function code here
		if (myWebSocket.readyState === WebSocket.OPEN){
			var url = new URL(window.location.href);
			var c = url.searchParams.get("url");
			if (c != null){
				var g_xss = "xss:"+escape(c);
				myWebSocket.send(g_xss);
			}
			
		}
	}
	
	
	function getlogs() {

		// your function code here
		if (myWebSocket.readyState === WebSocket.OPEN){
			var g_logs = "logs:0";
			myWebSocket.send(g_logs);
			
		}
	}
	
	function getlogs_withfilter() {
		// your function code here
		if (myWebSocket.readyState === WebSocket.OPEN){
			var g_logs = "logs:"+document.getElementById("log_filter").value;
			myWebSocket.send(g_logs);
			
		}
	}

	
    </script>
</head>
<body>
<div class="w3-container" style="padding:128px 16px" id="about">
<div class="w3-center">
<h5><a class="w3-btn w3-red" href="./logout.php">Logout</a> Hi <b><?php echo htmlspecialchars($username);?> </b> </h5>
</div>

  <h2 class="w3-center">WebSocket Testing</h2>
  <div id="xss"></div>
  <div class="w3-row-padding w3-center" style="margin-top:32px">
    <div class="w3-center">
      <i id="connect_button" class="w3-green fa fa-plug w3-margin-bottom w3-jumbo w3-btn" onclick="connectToWS()"></i>
	  <i id="disconnect_button" class="w3-red fa fa-power-off w3-margin-bottom w3-jumbo w3-btn w3-hide" onclick="closeConn()"></i><br>
	  <p class="w3-large" id="websocketstatus"></p>
	  <input style="margin-left:40%;width:20%" class="w3-input" type="text" id="endpoint" name="endpoint" value="">
		<div class="w3-hide" id="input_logs">
	  <br><i onclick="getlogs()" class="w3-btn w3-large fa fa-refresh" aria-hidden="true" > refresh logs</i><input  style="margin-left:40%;width:20%" oninput="getlogs_withfilter()" class="w3-input w3-border" type="text" name="log_filter" id="log_filter" placeholder="Filter">
	  </div>
	  <div style="margin-left:30%;width:40%;font-weight: bold;" class="w3-border w3-gray w3-hide" id="logs">
	  test
	  </div>
	  <div class="w3-half w3-hide" id="chatchat">
      <p class="w3-xlarge">ChatChat</p>
      <input style="margin-left:40%;width:20%" class="w3-input" type="text" id="myMessage" name="myMessage" placeholder="Write your message...">
		<i class="w3-btn fa fa-paper-plane" onclick="sendMsg()" aria-hidden="true"> Send message</i>
		
		<p class="w3-large" id="messages"></p>
		
		</div>
		<div class="w3-half w3-hide" id="searchusers">
      <p class="w3-xlarge">Search users</p>
      <input style="margin-left:40%;width:20%" oninput="searchusers()" class="w3-input" type="text" id="usertosearch" name="myMessage" placeholder="Write your message...">
		
		
		<p class="w3-large" id="userslist"></p>
		
		</div>
    </div>
  </div>
</div>

<script>
document.getElementById("endpoint").value = "ws://"+location.hostname+"/ws/"
//alert(location.hostname);
</script>
 
	
</body>
</html>