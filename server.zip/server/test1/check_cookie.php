<?php
function check_cookie($cookie){
	$servername = "localhost";
	$username = "test";
	$password = "test";
	$dbname = "websocket";

		// Create connection
		
		$conn = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($conn->connect_error) {
			return False;
		}



		$stmt = $conn->prepare("SELECT cookie FROM cookies WHERE cookie=(?)");
		$stmt->bind_param("s", $cookie_value);
		
		$cookie_value = $cookie;
		
		$stmt->execute();
		
		$result = $stmt->get_result();

		if ($result->num_rows > 0) {
			return True;
		} else {
			return False;
		}
	}
?>