<?php
// set the expiration date to one hour ago
setcookie("sessionID", "", time() - 3600);
?>
<html>
<body>

<?php
echo "Login out...";
?>
	<script>
		setTimeout(function () {
		   window.location.href= '/test1/portal.php'; // the redirect goes here

		},2000);
	</script>
</body>
</html>