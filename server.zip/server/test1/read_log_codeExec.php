<?php
#echo shell_exec('type C:\\xampp\\htdocs\\test1\\logs\\logs.txt');
function read_log($filter){
	#$file = file_get_contents('C:\\xampp\\htdocs\\test1\\logs\\logs.txt');
	if ($filter == '0' || $filter == ''){
		$file = shell_exec('type C:\\xampp\\htdocs\\test1\\logs\\logs.txt');
		return $file;
	} else {
		$file = shell_exec('type C:\\xampp\\htdocs\\test1\\logs\\logs.txt |findstr '.$filter);
		echo $file;
		return $file;
	}
	
}
#logs:1 & whoami
?>