Create DB and named it 'websocket' with the following creds:
$servername = "localhost";
$username = "test";
$password = "test";
$dbname = "websocket";


access to '/test1/createTables.php' - to create the tables